import React, { useState } from 'react';
import Chart from "../charts/charts.jsx"

export default function ConsultationForm() {
  return (
      <Chart/>
  );
}
